# EternalCombat 1.0.0

EternalCombat is a configurable PvP combat-tagging plugin. This source project uses the Bukkit/Spigot API baseline 1.19.3 and Java 17 bytecode.

## Features in this build
- Player and projectile PvP combat tagging
- Configurable combat duration
- Combat-log detection with next-login punishment
- Block configurable root commands during combat
- English configurable messages
- Boss bar and action bar enabled by default
- PvP enable toggle and optional world allowlist
- Staff bypass permission
- Tag sound and hit particles
- YAML data storage
- Admin commands: `/ec help`, `/ec reload`, `/ec status <player>`, `/ec tag <player> [seconds]`, `/ec untag <player>`
- `/combatstatus`

## Build
Requirements: JDK 17+ and Maven 3.9+ with internet access.

```sh
mvn clean package
```
Output: `target/EternalCombat-1.0.0.jar`.

## Install
1. Stop the server and back up it.
2. Put `EternalCombat-1.0.0.jar` in `plugins/`.
3. Start the server once to generate `plugins/EternalCombat/` files.
4. Edit `config.yml` and `messages.yml`, then use `/ec reload`.

## Commands and permissions
| Command | Permission | Purpose |
|---|---|---|
| `/ec help` | none | Help |
| `/ec reload` | `eternalcombat.admin.reload` | Reload main config |
| `/ec status <player>` | `eternalcombat.admin` | Inspect tag state |
| `/ec tag <player> [seconds]` | `eternalcombat.admin` | Manually tag a player |
| `/ec untag <player>` | `eternalcombat.admin` | Clear a tag |
| `/combatstatus` | none | Check own tag |
| Bypass | `eternalcombat.bypass` | Bypass tag/command restrictions |

Grant with LuckPerms, for example: `/lp group mod permission set eternalcombat.bypass true`.

## Important limitations
- `rewards.enabled` is a documented placeholder; economy rewards are not implemented in this build.
- `cooldowns.enabled` is reserved; this build uses the combat timer but does not implement a separate per-command cooldown system.
- Boss/action bar countdown refreshes on combat-related events; this starter build does not run a continuous per-tick display task.
- Combat-log kill is deferred until next login. A player entity has already disconnected when the quit event completes, so this avoids pretending the server can kill an offline entity.
- `folia-supported: true` is declared, but Folia compatibility must be tested on actual Folia builds. Some code paths use Bukkit scheduler/API behavior and this build should be treated as experimental on Folia until verified.


## Build online from a phone

See [BUILD_ON_GITHUB_PHONE.md](BUILD_ON_GITHUB_PHONE.md). The repository includes a GitHub Actions workflow that builds the JAR and publishes it as a downloadable workflow artifact.
