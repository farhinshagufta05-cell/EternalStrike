# Build EternalCombat online (phone-friendly)

This project includes a GitHub Actions workflow at `.github/workflows/build.yml`.
It asks GitHub's hosted runner to compile the Maven project and attach the resulting JAR as an artifact.

## Steps
1. Sign in to GitHub and create a **new repository** (a private repository is fine).
2. Upload the *contents* of this `EternalCombat` folder to the repository's root. Ensure `pom.xml` and `.github/workflows/build.yml` are at the root / expected path, not nested inside a second `EternalCombat` folder.
3. Open the repository's **Actions** tab. If GitHub asks, enable Actions for the repository.
4. Select **Build EternalCombat JAR** and tap **Run workflow** (or push to `main` to trigger it automatically).
5. Open the completed workflow run. Under **Artifacts**, download `EternalCombat-JAR` and extract it.
6. Upload the resulting `.jar` file—not the ZIP or source folder—to your server's `plugins` folder, then restart the server.

## Important
- A green build means the source compiled; it does not prove every feature works on every server version.
- This project has not been verified on every Minecraft version from 1.19.3 through 26.3.
- Do not claim Folia support unless its region/entity scheduling has been implemented and tested. The current project is not fully Folia-safe.
- Keep a backup of your server before testing a new plugin.
