# Compatibility notes

## Intended target matrix
- Minecraft 1.19.3 through 1.21.3: compiled against Spigot API 1.19.3 as a conservative common API baseline.
- Minecraft 1.21.4 through 26.3: best-effort only; must be smoke-tested on each target. Paper's API and development model diverged from Spigot after 1.21.3, so a Spigot-compiled jar is not a guarantee of support on every modern server.
- Purpur: generally follows Paper/Bukkit APIs, but test the exact version and enabled Purpur settings.
- Folia: experimental, not certified. The Folia marker alone does not establish thread safety; official docs require using region/entity/global schedulers correctly. This source's deferred combat-log punishment uses the Bukkit scheduler and must be ported to entity scheduling before claiming production Folia support.

Official reference: https://docs.papermc.io/paper/dev/folia-support/

## Release recommendation
For a genuinely supported 1.19.3–26.3 matrix, maintain CI builds against multiple API baselines and test Paper, Purpur, Folia, and Spigot separately. Keep common Bukkit API calls isolated from version-specific integrations. Do not advertise universal compatibility until that matrix passes.
