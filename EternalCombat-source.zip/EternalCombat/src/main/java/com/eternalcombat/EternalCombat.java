package com.eternalcombat;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.entity.Projectile;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** EternalCombat: conservative Bukkit API combat tagging plugin. */
public final class EternalCombat extends JavaPlugin implements Listener {
    private final Map<UUID, Long> taggedUntil = new ConcurrentHashMap<>();
    private final Map<UUID, BossBar> bars = new ConcurrentHashMap<>();
    private File dataFile;
    private YamlConfiguration data;

    @Override public void onEnable() {
        saveDefaultConfig();
        if (!new File(getDataFolder(), "messages.yml").exists()) saveResource("messages.yml", false);
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        getServer().getPluginManager().registerEvents(this, this);
        for (Player p : Bukkit.getOnlinePlayers()) updateDisplay(p);
        getLogger().info("EternalCombat enabled. API-only mode; see COMPATIBILITY.md for platform notes.");
    }

    @Override public void onDisable() {
        for (BossBar bar : bars.values()) { try { bar.removeAll(); } catch (Throwable ignored) {} }
        bars.clear();
        saveData();
    }

    private String msg(String key) {
        YamlConfiguration m = YamlConfiguration.loadConfiguration(new File(getDataFolder(), "messages.yml"));
        return ChatColor.translateAlternateColorCodes('&', m.getString(key, "&cMissing message: " + key));
    }
    private boolean bypass(Player p) { return p.hasPermission("eternalcombat.bypass"); }
    private long remaining(Player p) { return Math.max(0L, taggedUntil.getOrDefault(p.getUniqueId(), 0L) - System.currentTimeMillis()); }
    public boolean isTagged(Player p) { if (bypass(p)) return false; if (remaining(p) <= 0) { clearTag(p); return false; } return true; }
    private void clearTag(Player p) {
        taggedUntil.remove(p.getUniqueId());
        BossBar b = bars.remove(p.getUniqueId()); if (b != null) b.removePlayer(p);
        if (p.isOnline()) p.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(" "));
    }
    private void tag(Player p) {
        if (bypass(p) || !getConfig().getBoolean("combat.enabled", true)) return;
        int seconds = Math.max(1, getConfig().getInt("combat.duration-seconds", 15));
        taggedUntil.put(p.getUniqueId(), System.currentTimeMillis() + seconds * 1000L);
        updateDisplay(p);
        p.sendMessage(msg("tagged").replace("{seconds}", String.valueOf(seconds)));
        String sound = getConfig().getString("effects.tag-sound", "ENTITY_EXPERIENCE_ORB_PICKUP");
        try { p.playSound(p.getLocation(), org.bukkit.Sound.valueOf(sound), 0.7f, 1.2f); } catch (IllegalArgumentException ignored) {}
    }
    private void updateDisplay(Player p) {
        long ms = remaining(p); if (ms <= 0 || bypass(p)) { clearTag(p); return; }
        int total = Math.max(1, getConfig().getInt("combat.duration-seconds", 15));
        String text = msg("actionbar").replace("{seconds}", String.valueOf((ms + 999) / 1000));
        if (getConfig().getBoolean("display.actionbar", true)) p.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(text));
        if (getConfig().getBoolean("display.bossbar", true)) {
            BossBar bar = bars.computeIfAbsent(p.getUniqueId(), id -> Bukkit.createBossBar(msg("bossbar"), BarColor.RED, BarStyle.SOLID));
            bar.setTitle(msg("bossbar").replace("{seconds}", String.valueOf((ms + 999) / 1000)));
            bar.setProgress(Math.max(0.0, Math.min(1.0, ms / (total * 1000.0))));
            if (!bar.getPlayers().contains(p)) bar.addPlayer(p);
        }
    }
    private Player getPlayerDamager(org.bukkit.entity.Entity e) {
        if (e instanceof Player p) return p;
        if (e instanceof Projectile projectile) {
            ProjectileSource s = projectile.getShooter(); if (s instanceof Player p) return p;
        }
        return null;
    }
    @EventHandler public void onDamage(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player victim)) return;
        Player attacker = getPlayerDamager(e.getDamager());
        if (attacker == null || attacker.equals(victim)) return;
        if (!getConfig().getBoolean("pvp.enabled", true)) { e.setCancelled(true); return; }
        if (getConfig().getBoolean("pvp.respect-worlds", false) && !getConfig().getStringList("pvp.allowed-worlds").contains(victim.getWorld().getName())) { e.setCancelled(true); return; }
        tag(attacker); tag(victim);
        if (getConfig().getBoolean("effects.particles", true)) {
            try { victim.getWorld().spawnParticle(org.bukkit.Particle.CRIT, victim.getLocation().add(0, 1, 0), 5, .25, .35, .25, .05); } catch (Throwable ignored) {}
        }
    }
    @EventHandler public void onCommand(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer(); if (!isTagged(p) || bypass(p)) return;
        String raw = e.getMessage().substring(1).split(" ")[0].toLowerCase();
        for (String blocked : getConfig().getStringList("commands.blocked")) {
            String normalized = blocked.toLowerCase().replaceFirst("^/", "");
            if (raw.equals(normalized) || raw.startsWith(normalized + ":")) { e.setCancelled(true); p.sendMessage(msg("command-blocked")); return; }
        }
    }
    @EventHandler public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        if (isTagged(p) && getConfig().getBoolean("combatlog.kill-on-disconnect", true)) {
            data.set("combatlog." + p.getUniqueId(), System.currentTimeMillis());
            saveData();
            getLogger().info("Combat-log recorded for " + p.getName() + " (disconnect punishment: kill). Server cannot kill an entity after it has disconnected; next-login punishment is applied.");
        }
        BossBar b = bars.remove(p.getUniqueId()); if (b != null) b.removePlayer(p);
        taggedUntil.remove(p.getUniqueId());
    }
    @EventHandler public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer(); String key = "combatlog." + p.getUniqueId();
        if (data.contains(key)) {
            data.set(key, null); saveData();
            Bukkit.getScheduler().runTask(this, () -> { if (p.isOnline() && getConfig().getBoolean("combatlog.kill-on-disconnect", true)) { p.setHealth(0.0); p.sendMessage(msg("combatlog-punished")); } });
        }
    }
    @EventHandler public void onDeath(PlayerDeathEvent e) { clearTag(e.getEntity()); }

    private void saveData() { if (data == null || dataFile == null) return; try { data.save(dataFile); } catch (IOException ex) { getLogger().warning("Could not save data.yml: " + ex.getMessage()); } }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("eternalcombat")) {
            if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
                sender.sendMessage("§6EternalCombat §7Commands: /ec reload, /ec status <player>, /ec untag <player>, /ec tag <player> [seconds]"); return true;
            }
            if (args[0].equalsIgnoreCase("reload")) {
                if (!sender.hasPermission("eternalcombat.admin.reload")) { sender.sendMessage(msg("no-permission")); return true; }
                reloadConfig(); sender.sendMessage(msg("reloaded")); return true;
            }
            if (args.length >= 2 && (args[0].equalsIgnoreCase("status") || args[0].equalsIgnoreCase("untag") || args[0].equalsIgnoreCase("tag"))) {
                if (!sender.hasPermission("eternalcombat.admin")) { sender.sendMessage(msg("no-permission")); return true; }
                Player target = Bukkit.getPlayerExact(args[1]); if (target == null) { sender.sendMessage(msg("player-not-found")); return true; }
                if (args[0].equalsIgnoreCase("status")) sender.sendMessage("§e" + target.getName() + " tagged: " + isTagged(target) + " (" + ((remaining(target)+999)/1000) + "s)");
                else if (args[0].equalsIgnoreCase("untag")) { clearTag(target); target.sendMessage(msg("untagged")); sender.sendMessage("§aTag cleared."); }
                else { int seconds = 15; if (args.length >= 3) try { seconds = Math.max(1, Math.min(3600, Integer.parseInt(args[2]))); } catch (NumberFormatException ignored) {} taggedUntil.put(target.getUniqueId(), System.currentTimeMillis() + seconds * 1000L); updateDisplay(target); sender.sendMessage("§aTagged " + target.getName() + " for " + seconds + "s."); }
                return true;
            }
            sender.sendMessage("§cInvalid usage. Use /ec help."); return true;
        }
        if (command.getName().equalsIgnoreCase("combatstatus") && sender instanceof Player p) {
            sender.sendMessage(isTagged(p) ? msg("status-tagged").replace("{seconds}", String.valueOf((remaining(p)+999)/1000)) : msg("status-safe")); return true;
        }
        return false;
    }
}
